package com.fz.orm.core;

/**
 * 针对mysql数据库的查询
 * <br><br><strong>时间:</strong><br>
 * &nbsp;&nbsp;&nbsp;&nbsp;2015年10月29日 上午10:41:56<br>
 * @author FZ
 * @version 1.0
 */
public class MySqlQuery extends Query {
	/**
	 * 分页查询
	 */
	@Override
	public Object findPagenate(int pageNum, int size) {
		
		return null;
	}

}
